This is the assignment 2 for group 24.
The application best works in landscape mode for filling up the data and then can be put in portrait mode for viewing the graph!


Participants are:
Anitharaj Natarajan
Prachi More
Varsha Muzumdar
Arun Subramanian